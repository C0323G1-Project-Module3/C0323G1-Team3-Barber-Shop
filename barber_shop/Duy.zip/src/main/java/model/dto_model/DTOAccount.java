package model.dto_model;
public class DTOAccount {
}
