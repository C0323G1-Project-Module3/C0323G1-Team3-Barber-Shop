package model;

public class BookingDetailEmployee {
}
