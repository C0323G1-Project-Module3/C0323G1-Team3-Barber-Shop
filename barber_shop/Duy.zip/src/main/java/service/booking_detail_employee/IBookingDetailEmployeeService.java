package service.booking_detail_employee;

public interface IBookingDetailEmployeeService {
}
