package service.booking_detail_employee.impl;

public class BookingDetailEmployeeService {
}
