package service.role.impl;

public class RoleService {
}
