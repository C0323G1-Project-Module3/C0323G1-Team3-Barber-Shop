package service.role;

public interface IRoleService {
}
