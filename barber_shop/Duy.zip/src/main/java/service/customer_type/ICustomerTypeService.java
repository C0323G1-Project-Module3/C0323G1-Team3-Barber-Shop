package service.customer_type;

public interface ICustomerTypeService {
}
