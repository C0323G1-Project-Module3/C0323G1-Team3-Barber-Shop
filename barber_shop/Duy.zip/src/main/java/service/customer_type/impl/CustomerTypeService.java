package service.customer_type.impl;

public class CustomerTypeService {
}
