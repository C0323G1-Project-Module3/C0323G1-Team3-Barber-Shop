package common.regex;

public class Regex {
}
