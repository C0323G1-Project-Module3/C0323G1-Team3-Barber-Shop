package repository.booking_detail_employee.impl;

public class BookingDetailEmployeeRepository {
}
