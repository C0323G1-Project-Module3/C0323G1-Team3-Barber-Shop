package repository.booking_detail_employee;

public interface IBookingDetailEmployeeRepository {
}
