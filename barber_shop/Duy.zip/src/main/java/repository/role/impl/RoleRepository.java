package repository.role.impl;

public class RoleRepository {
}
