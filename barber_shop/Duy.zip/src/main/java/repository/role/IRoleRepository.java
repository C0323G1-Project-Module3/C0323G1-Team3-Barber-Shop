package repository.role;

public interface IRoleRepository {
}
