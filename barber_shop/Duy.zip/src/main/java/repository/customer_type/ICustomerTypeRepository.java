package repository.customer_type;

public interface ICustomerTypeRepository {
}
