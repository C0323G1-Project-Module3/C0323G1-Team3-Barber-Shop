package repository.customer_type.impl;

public class CustomerTypeRepository {
}
